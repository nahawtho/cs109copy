#include <stdio.h>
#include <stdlib.h> //malloc
#include <string.h> //strlen
#include <math.h>
#include "stack.h"
/*
 * Reverse Polish Notation (RPN) Calculator
 *
 * Accepts a single argument in RPN, evaluates it and prints the answer to stdout.
 * 
 * Returns -1 on error, 0 otherwise.
 */
// https://stackoverflow.com/questions/45128685/c-store-command-line-argument-as-an-array-of-char
// https://stackoverflow.com/questions/266357/tokenizing-strings-in-c
// https://www.tutorialspoint.com/data_structures_algorithms/stack_program_in_c.htm
// https://cboard.cprogramming.com/cplusplus-programming/33859-how-can-i-determine-whether-string-represents-integer-not.html

int power(int x,int n);

int main(int argc, char *argv[]) {
	//	read input	
	int num1;

	char *string = malloc(strlen(argv[1]) + 1); //strlen returns the size of the string not including the null character at the end.
	strcpy(string,argv[1]);
//	printf("%s", string);
	
	//	tokenize
	char* token = strtok(string, " ");
	while (token){
	//	printf("%s\n", token); // print token
		num1 = atoi(token);
		if ( *token != '0' && num1 == 0) {
	//		printf("not an integer\n");
			if (*token == '+') {
//				printf("found +\n");
			 	int sum = pop() + pop();
//				printf("sum %d\n", sum);
				push(sum);
			}
			if (*token == '-') {
//				printf("found minus");
				int pop1 = pop();
				int pop2 = pop();
				int diff = pop2 - pop1;
//				printf("difference %d\n", diff);
				push(diff);		// push difference back on to stack	
			}
			if (*token == '*') {
//				printf("found star");
				int prod = pop() * pop();
//				printf("product: %d\n", prod);
				push(prod);
			}
			if (*token == '^') {
//				printf("found ^");
				int pop1 = pop();
				int pop2 = pop();
				int pow = (power(pop2, pop1));
//				printf("power  %d\n", pow);
				push(pow);
			}
			if (*token == '/') {
//				printf("found /");
                                int pop1 = pop();
                                int pop2 = pop();
                                int quotient = pop2 / pop1;
//                              printf("quotient  %d\n", quotient);
                                push(quotient);
			}
				
		}
		else { 
// 			printf("atoid int is: %d\n", num1);
			push(num1);
		}
			token = strtok(NULL, " "); // next token
	}


	int answer = pop();
	printf("%d", answer);
// iff error return -1
	free(string);
	return 0;
}
int power(int x,int n)
{
    int i; /* Variable used in loop counter */
    int num = 1;

    for (i = 0; i < n; i++)
        num *= x;

    return(num);
}
