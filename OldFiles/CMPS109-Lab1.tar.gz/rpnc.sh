#
# Bash Reverse Polish Notation (RPN) Calculator
#
# Accepts an single argument a RPN, evaluates it and prints the answer to stdout.
# 
# https://opencast-player-1.lt.ucsc.edu:8443/engage/theodul/ui/core.html?id=3a5146d8-19ca-4e50-9af1-e2e03d211139
set -f
arr=()
nxt=0
for token in $1
do
	if [[ "$token" == "+"  ]] || [[ "$token" == "-"  ]] || [[ "$token" == "*"  ]] || [[ "$token" == "^" ]] || [[ "$token" == "/" ]]; then
#		echo "$token"
		((nxt--))
		num1=${arr[$nxt]}
#		echo "$num1"
		((nxt--))
		num2=${arr[$nxt]}
#		echo "$num2"
		if [[ "$token" == "+"  ]]; then
			sum=$((num1 + num2))
			arr[$nxt]=$sum
			((nxt++))
		fi
		if [[ "$token" == "-"  ]]; then
			diff=$((num2 - num1))
			arr[$nxt]=$diff
			((nxt++))
		fi
		if [[ "$token" == "*" ]]; then
			prod=$((num1 * num2))
			arr[$nxt]=$prod
			((nxt++))
		fi
		if [[ "$token" == "^" ]]; then
                        pow=$((num2 ** num1))
                        arr[$nxt]=$pow
                        ((nxt++))
		fi
		if [[ "$token" == "/" ]]; then
                        quot=$((num2 / num1))
                        arr[$nxt]=$quot
                        ((nxt++))	
		fi
	else
#		echo "Operand! $token"		
		arr[$nxt]=$token
		((nxt++))
	fi
done
echo ${arr[0]}

