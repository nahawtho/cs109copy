#
# Python3 Reverse Polish Notation (RPN) Calculator
#
# Accepts an single argument in RPN, evaluates it and prints the answer to stdout.
# 
import sys
# print (sys.argv[1])

list = sys.argv[1].split(' ')

stack = []

i=0
while(i < len(list)-1 ):
	if (list[i] == '+' or list[i] == '-' or list[i] == '*' or list[i] == '^' or list[i] == '/'):
		if (list[i] == '+'):
			total = int(stack.pop()) + int(stack.pop())
			stack.append(total)
		if (list[i] == '-'):
                        total = int(stack.pop()) - int(stack.pop())
                        stack.append(-total)	
		if (list[i] == '*'):
                        total = int(stack.pop()) * int(stack.pop())
                        stack.append(total)
		if (list[i] == '/'):
                        total = int(stack.pop()) / int(stack.pop())
                        stack.append(1/total)
		if (list[i] == '^'):
                        num1 = int(stack.pop())
                        num2 = int(stack.pop())
                        power = num2 ** num1
                        stack.append(power)
	else:
		stack.append(list[i])
	i+=1
print(stack.pop())
print(" ")
