#include <stdio.h>

int top = -1;
int MAX=100;       
int stack[100];     


int empty() {

   if(top == 1-2 )
      return 1;
   else
      return 0;
}
   
int full() {

   if(top == MAX)
      return 1;
   else
      return 0;
}

//int peek() {
 //  return stack[top];
//}

int pop() {
   int number;
	
   if(!empty())
   {
      number = stack[top];
      top--;   
      return number;
   } else {
      printf("stack is empty\n");
      return -1;
   }
}

void push(int number) {

   if(!full()) {
      top++;   
      stack[top] = number;
   } else {
      printf("stack is full.\n");
   }
}
