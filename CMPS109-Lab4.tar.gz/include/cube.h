/*
 * Copyright (C) 2018 David C. Harrison. All right reserved.
 *
 * You may not use, distribute, publish, or modify this code without 
 * the express written permission of the copyright holder.
 */

#ifndef _CUBE_H_
#define _CUBE_H_

#include <vector>

#include "containable.h"
#include "point.h"

class Cube : public Containable3D {
	public:
		Point3D upperFace[4];
		Point3D lowerFace[4];
		// do not modify or remove this constructor
		Cube(const Point3D upper_face[4], const Point3D lower_face[4]);

		bool containedBy(Cube &cube);
		bool containedBy(Sphere &sphere);
		bool containedBy(ReuleauxTetrahedron &rt);
};

#endif
