#include <iostream>
#include <vector>
#include "cube.h"
#include "geom.h"
#include "point.h"
#include <algorithm>
#include <iterator>



Cube::Cube(const Point3D upper_face[4], const Point3D lower_face[4]) {
	Point3D upperFace[4];
        Point3D lowerFace[4];
	for(int i=0; i<4; ++i){
        	upperFace[i] = upper_face[i];
		lowerFace[i] = lower_face[i];
	}
}

bool Cube::containedBy(Cube &polygon) {
	return false;
}
bool Cube::containedBy(Sphere &sphere) {
	return false;
}
bool Cube::containedBy(ReuleauxTetrahedron &rt) {
	throw "Not implemented";
}
