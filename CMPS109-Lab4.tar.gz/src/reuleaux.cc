#include <vector>
#include "reuleaux.h"
#include "point.h"
#include "containable.h"

ReuleauxTriangle::ReuleauxTriangle(const Point vertices[3]) {

	std::vector<Point> vecpts (vertices, vertices + sizeof(*vertices)
							/ sizeof(Point));
}
std::vector<Point> ReuleauxTriangle::vertices(){
	return vecpts;
}

bool ReuleauxTriangle::containedBy(Circle &circle){
	throw "not implemented";
}

bool ReuleauxTriangle::containedBy(RegularConvexPolygon &polygon){
	throw "not implemented";
}

bool ReuleauxTriangle::containedBy(ReuleauxTriangle &rt){
	throw "not implemented";
}
bool ReuleauxTriangle::containedBy(ConvexPolygon &cp){
	throw "not implemented";
}

ReuleauxTetrahedron::ReuleauxTetrahedron(const Point3D vertices[4]){
	Point3D vertices_[4];
	for (int i = 0; i < 4; i++) vertices_[i] = vertices[i];
}
bool ReuleauxTetrahedron::containedBy(Cube &cube){
        throw "not implemented";
}

bool ReuleauxTetrahedron::containedBy(Sphere &sphere){
        throw "not implemented";
}

bool ReuleauxTetrahedron::containedBy(ReuleauxTetrahedron &rt){
        throw "not implemented";
}

