#include <iostream>
#include "cube.h"
#include "reuleaux.h"
#include "containable.h"
#include "sphere.h"
#include "point.h"


Sphere::Sphere(const Point3D &center, double radius){
	Point3D center_ = center;
	std::cout << "sphere center" << center_.x;
	double rad = radius;
	std::cout << "sphere radius" << rad;
}

bool Sphere::containedBy(Cube &cube){
throw "Not implemented";
}
bool Sphere::containedBy(Sphere &sphere){
throw "Not implemented";
}
bool Sphere::containedBy(ReuleauxTetrahedron &rt){
throw "Not implemented";
}
